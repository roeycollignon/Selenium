[![Stories in Ready](https://badge.waffle.io/QualiSystems/AWS-Shell.svg?label=ready&title=Ready)](http://waffle.io/QualiSystems/AWS-Shell) [![Stories in Progress](https://badge.waffle.io/QualiSystems/AWS-Shell.svg?label=in%20progress&title=In%20Progress)](http://waffle.io/QualiSystems/AWS-Shell)[ ![Foo](https://qualisystems.getbadges.io/shield/company/qualisystems) ](https://getbadges.io) [![Coverage Status](https://coveralls.io/repos/github/QualiSystems/AWS-Shell/badge.svg?branch=develop)](https://coveralls.io/github/QualiSystems/AWS-Shell?branch=develop)

# AWS-Shell
A CloudShell 'Shell' that allows integrating AWS as an app's deployment option.
